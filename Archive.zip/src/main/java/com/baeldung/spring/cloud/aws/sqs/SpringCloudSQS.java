package com.baeldung.spring.cloud.aws.sqs;

import java.util.concurrent.CountDownLatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.cloud.aws.messaging.listener.SqsMessageDeletionPolicy;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.context.annotation.Lazy;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

@Component
@Lazy
public class SpringCloudSQS {

    private static final Logger logger = LoggerFactory.getLogger(SpringCloudSQS.class);

    static final String QUEUE_NAME = "HEMANT_SQS_DEMO_QUEUE1.fifo";

    /*
     * CountDownLatch is added to wait for messages
     * during integration test
     */
    CountDownLatch countDownLatch;

    public void setCountDownLatch(CountDownLatch countDownLatch) {
        this.countDownLatch = countDownLatch;
    }

    @Autowired
    QueueMessagingTemplate queueMessagingTemplate;

    @SqsListener(value = QUEUE_NAME, deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
    public void receiveMessage(String message, @Header("SenderId") String senderId) throws Exception {
        logger.info("Received message: {}, having SenderId: {}", message, senderId);
        throw new Exception("OOPS");
    }

    public void send(String queueName, Object message) {
        queueMessagingTemplate.convertAndSend(queueName, message);
    }
}
